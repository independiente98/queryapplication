package com.example.queryapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class ChaXunActivity extends AppCompatActivity {
    private List<ChaXun> ChaXunList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cha_xun);
        Intent intent = getIntent();
        final String info = intent.getStringExtra("info");
        System.out.println(info);
        initChaXun();
        ChaXunAdapter adapter = new ChaXunAdapter(ChaXunActivity.this, R.layout.chaxun_item, ChaXunList);
        ListView listView = (ListView) findViewById(R.id.listview_cha_xun);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ChaXun chaXun = ChaXunList.get(position);
                switch (position) {
                    case 0:
                        Intent intent = new Intent(ChaXunActivity.this, QueryActivity.class);
                        intent.putExtra("info", info);
                        startActivity(intent);
                        break;
                    case 1:
                        Toast.makeText(ChaXunActivity.this, "服务暂未开通", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Toast.makeText(ChaXunActivity.this, "服务暂未开通", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }

            }
        });
    }

    private void initChaXun() {
        ChaXun canBao = new ChaXun("个人社保信息查询", 0);
        ChaXunList.add(canBao);
        ChaXun sheBao = new ChaXun("社保卡状态查询", 1);
        ChaXunList.add(sheBao);
        ChaXun liTui = new ChaXun("离退休人员基本信息", 2);
        ChaXunList.add(liTui);
    }
}
