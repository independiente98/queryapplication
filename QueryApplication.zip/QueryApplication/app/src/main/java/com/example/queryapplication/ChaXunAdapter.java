package com.example.queryapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by 001 on 2018/2/6.
 */

public class ChaXunAdapter extends ArrayAdapter<ChaXun> {
    private int resourceId;
    public ChaXunAdapter(Context context, int textViewResourceId, List<ChaXun> objects) {
        super(context,textViewResourceId,objects);
        resourceId=textViewResourceId;
    }
        @Override
        public View getView ( int position, View convertView, ViewGroup parent){
            ChaXun chaXun=getItem(position);
            View view;
                    if(convertView==null){
                        view= LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
                    }else{
                        view=convertView;
                    }
            TextView chaxunName=(TextView)view.findViewById(R.id.chaxun_name);
            chaxunName.setText(chaXun.getName());
            return view;
        }

    }

