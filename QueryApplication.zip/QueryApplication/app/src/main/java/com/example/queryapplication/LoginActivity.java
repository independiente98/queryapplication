package com.example.queryapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.queryapplication.mima.BackAES;
import com.example.queryapplication.mima.MimaUtil;
import com.okhttplib.HttpInfo;
import com.okhttplib.OkHttpUtil;
import com.okhttplib.annotation.Encoding;
import com.okhttplib.callback.Callback;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;



public class LoginActivity extends AppCompatActivity{
 private EditText  accountEdit;
    private EditText passwordEdit;
    private Button login;
    String msg;
    String msgflag;
    String banner;
    String rolling;
    final String checkServer="server";
    int flag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        JSONObject object = new JSONObject();
        try {
            object.put("ywlx", checkServer);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String postData = MimaUtil.jiami(object);
        String result1 = null;
        try {
            result1 = BackAES.decrypt(postData, "xzHrss@!206%Toni", 1);
            System.out.println("jiemi="+result1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        sync(postData);
        accountEdit=(EditText) findViewById(R.id.account);
        passwordEdit=(EditText) findViewById(R.id.password);
        login=(Button)findViewById(R.id.login);
        accountEdit.setText("usertest");
        passwordEdit.setText("123456");
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=accountEdit.getText().toString();
                String cpassword=passwordEdit.getText().toString();
                final TelephonyManager tm;
                tm = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
                String codeid=tm.getDeviceId();
                System.out.println(codeid+" ");
                JSONObject object = new JSONObject();
                try {
                    object.put("username", username);
                    object.put("cpassword", cpassword);
                    object.put("codeid",codeid);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String postData = MimaUtil.jiami(object);
                String result1 = null;
                try {
                    result1 = BackAES.decrypt(postData, "xzHrss@!206%Toni", 1);
                    System.out.println("jiemi="+result1);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                async(postData);


            }
        });
    }
   /**/ private void sync(final String string) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final HttpInfo info = HttpInfo.Builder()
                        .setUrl("https://app.jsxzhrss.gov.cn/xzrs/test/checkservernew.ke")
                        .setResponseEncoding(Encoding.UTF_8)//设置该接口的服务器响应编码
                        .setRequestEncoding(Encoding.UTF_8)//设置该接口的请求参数编码
                        .addParam("postData",string)
                        .build();
                OkHttpUtil.getDefault(this)
                        .doGetSync(info);
                final String result = info.getRetDetail();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("LoginActivity",result);
                        try {
                            JSONObject object =MimaUtil.jiemi(result);

                            msgflag = object.has("msgflag") ? object.get("msgflag").toString() : "";
                            banner = object.has("msg") ? object.get("msg").toString() : "";
                            flag=Integer.parseInt(msgflag);
                            System.out.println(banner);
                            Log.d("msgflag",msgflag);
                            System.out.println("flag="+flag);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (flag==-1){
                            Toast.makeText(LoginActivity.this,"the server is bad,closing app",Toast.LENGTH_SHORT).show();
                            onDestroy();
                        }else {
                            System.out.println("Server is functional");
                        }

                    }
                });
            }
        }).start();
    }

    private void async(String string) {
        OkHttpUtil.getDefault(this)
                .doPostAsync(
                HttpInfo.Builder().setUrl("https://app.jsxzhrss.gov.cn/xzrs/login.ke")
                        .addParam("postData",string)
                        .build(),
                new Callback() {
                    @Override
                    public void onFailure(HttpInfo info) throws IOException {
                        String result = info.getRetDetail();
                        System.out.println("异步请求失败：" + result);
                    }

                    @Override
                    public void onSuccess(HttpInfo info) throws IOException {
                        String result = info.getRetDetail();
                        try {
                            JSONObject object =MimaUtil.jiemi(result);
                            msgflag = object.has("msgflag") ? object.get("msgflag").toString() : "";
                            msg = object.has("msg") ? object.get("msg").toString() : "";
                            flag=Integer.parseInt(msgflag);
                            System.out.println(msg);
                            Log.d("msgflag",msgflag);
                            System.out.println("flag="+flag);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        System.out.println("异步请求成功：" + result);
                        //GSon解析
                        if(flag==-1){
                            Toast.makeText(LoginActivity.this,"account or password is wrong",Toast.LENGTH_SHORT).show();
                        }else{
                            Intent intent=new Intent(LoginActivity.this, MainActivity.class);

                            intent.putExtra("username",msg);
                            intent.putExtra("banner",banner);
                            intent.putExtra("rolling",rolling);
                            startActivity(intent);
                            finish();

                        }

                    }
                });
    }
}
