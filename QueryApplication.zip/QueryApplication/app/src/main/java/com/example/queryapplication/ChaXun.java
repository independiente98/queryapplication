package com.example.queryapplication;

import java.io.Serializable;

/**
 * Created by 001 on 2018/2/5.
 */

public class ChaXun {
 private String name;
    private int ywlx;
    public ChaXun(String name, int ywlx){
        this.name=name;
        this.ywlx=ywlx;
    }

    public int getYwlx() {
        return ywlx;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setYwlx(int ywlx) {
        this.ywlx = ywlx;
    }
}


