package com.example.queryapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class QueryActivity extends AppCompatActivity {
    private String[] data = {"个人代码", "身份证号码", "姓名", "人员状态", "待遇状态", "性别", "参保状态", "参保险种"};
    Query query = new Query();
    ArrayList<Query> xinxi = new ArrayList<Query>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        String info = intent.getStringExtra("info");
        System.out.println(info);
        initkeys(info);
        // String[] data = xinxi.toArray(new String[xinxi.size()]);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);
        //data=info.split(",");
        QueryAdapter adapter = new QueryAdapter(QueryActivity.this, R.layout.query_item, xinxi);
        ListView listView = (ListView) findViewById(R.id.listview_query);
        listView.setAdapter(adapter);
    }

    private void initkeys(String obj) {
        JSONArray dataArr = null;
        try {
            dataArr = new JSONArray(obj);

            for (int i = 0; i < dataArr.length(); i++) {
                JSONObject object = dataArr.getJSONObject(i);
                Iterator<String> it = object.keys();
                int j = 0;
                while (it.hasNext()) {
                    Query query1 = new Query();

                    String key = it.next().toString();
                    String value = object.getString(key);
                    System.out.println("key: " + key + " ** value: " + value);
                    query1.setKey(key);
                    query1.setValue(value);
                    System.out.println(query1.getKey() + "====" + query1.getValue());
                    xinxi.add(j, query1);
                    j++;
                }

            }
            for (int i = 0; i < xinxi.size(); i++) {
                Query query = new Query();
                query = xinxi.get(i);
                System.out.println(query.getKey() + "------" + query.getValue());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

