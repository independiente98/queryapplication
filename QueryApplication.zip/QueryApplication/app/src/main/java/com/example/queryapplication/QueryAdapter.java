package com.example.queryapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import com.example.queryapplication.Query;
import com.example.queryapplication.R;

import java.util.ArrayList;


/**
 * Created by 001 on 2018/2/7.
 */

public class QueryAdapter extends ArrayAdapter<Query> {
    private int resourceId;
    public QueryAdapter(Context context, int textViewResourceId, ArrayList<Query> objects) {
        super(context,textViewResourceId,objects);
        resourceId=textViewResourceId;
    }
    @Override
    public View getView (int position, View convertView, ViewGroup parent){
        Query query=getItem(position);
        View view;
        if(convertView==null){
            view= LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
        }else{
            view=convertView;
        }
        TextView queryName=(TextView)view.findViewById(R.id.query_name);
        queryName.setText(query.getKey()+":"+query.getValue());
        return view;
    }
}
