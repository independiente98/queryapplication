package com.example.queryapplication.util;

import android.text.TextUtils;

import org.json.JSONObject;

/**
 * Created by 001 on 2018/2/5.
 */

public class Utility {
    private  static String username;
    private static int cpassword;
    public static int handleMiMaResponse(String response) {

        if (!TextUtils.isEmpty(response)) {
            try {
                JSONObject loginObject = new JSONObject(response);
                username=loginObject.getString("username");
                cpassword=loginObject.getInt("cpassword");
               ;
                return 0;
            }
            catch (Exception e) {
                e.printStackTrace();
            }

        } return -1;
    }
}