package com.example.queryapplication.mima;

import android.support.annotation.NonNull;

import com.example.queryapplication.mima.BackAES;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.example.queryapplication.mima.BackAES;

import org.json.JSONException;
import org.json.JSONObject;

public class MimaUtil {

    @NonNull
    public static String jiami(JSONObject jsonObject) {
        String ob = jsonObject.toString();
            /* 加密 **/
        byte[] data1 = new byte[0];
        try {
            data1 = BackAES.encrypt(ob, "xzHrss@!206%Toni", 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new String(data1);
    }

   //@NonNull
//    public static JSONObject jiemi(String s) throws JSONException {
//        JSONObject res = new JSONObject(s);
//        String resData = res.has("resultData") ? res.get("resultData").toString() : "";
//        String result1 = null;
//        try {
//            result1 = BackAES.decrypt(resData, "xzHrss@!206%Toni", 1);
//            System.out.println("res::::" + result1);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return new JSONObject(result1);
//    }

    @NonNull
    public static JSONObject jiemi(String s) throws JSONException {
        JSONObject res = new JSONObject(s);
        String resData = res.has("resultData") ? res.get("resultData").toString() : "";
        String result1 = null;
        try {
            result1 = BackAES.decrypt(resData, "xzHrss@!206%Toni", 1);
            //System.out.println("res::::" + result1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new JSONObject(result1);
    }

    @NonNull
    public static JsonObject jiemi2(String s) throws JSONException {
        JSONObject res = new JSONObject(s);
        String resData = res.has("resultData") ? res.get("resultData").toString() : "";
        String result1 = null;
        try {
            result1 = BackAES.decrypt(resData, "xzHrss@!206%Toni", 1);
           // System.out.println("res::::" + result1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (JsonObject) new JsonParser().parse(result1);
    }


}
