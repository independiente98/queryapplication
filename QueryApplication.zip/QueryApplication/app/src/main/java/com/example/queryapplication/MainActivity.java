package com.example.queryapplication;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.queryapplication.BannerLayout.OnItemClickListener;
import com.example.queryapplication.mima.BackAES;
import com.example.queryapplication.mima.MimaUtil;
import com.okhttplib.HttpInfo;
import com.okhttplib.OkHttpUtil;
import com.okhttplib.callback.Callback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {
    String postData;
    String msg;
    String msgflag;
    int flag;
    String banner;
    BannerLayout bl;
    BannerLayout b2;
    Button query;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();
      username = intent.getStringExtra("username");
        banner=intent.getStringExtra("banner");
        System.out.println(username);
       initkeys(banner);
        query = (Button) findViewById(R.id.chaxun);
        query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ywlx = "app006";
                JSONObject object = new JSONObject();
                try {
                    object.put("username", username);
                    object.put("ywlx", ywlx);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                 postData = MimaUtil.jiami(object);
                String result1 = null;
                try {
                    result1 = BackAES.decrypt(postData, "xzHrss@!206%Toni", 1);
                    System.out.println("jiemi=" + result1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                async(postData);
            }
        });
        bl = (BannerLayout) findViewById(R.id.banner1);
        b2 = (BannerLayout) findViewById(R.id.banner2);
        bl.setOnItemClickListener(new OnItemClickListener() {

            public void onClick(int index, View childview) {
                // TODO Auto-generated method stub
                Toast.makeText(getApplicationContext(), "点击了index：" + index, Toast.LENGTH_SHORT).show();
            }
        });
        b2.setOnItemClickListener(new OnItemClickListener() {

            public void onClick(int index, View childview) {
                // TODO Auto-generated method stub
                Toast.makeText(getApplicationContext(), "点击了index：" + index, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    @Override
    protected void onPause() {
        bl.stopScroll();
        b2.stopScroll();
        super.onPause();
    }

    @Override
    protected void onRestart() {
        if (!bl.isScrolling())
            bl.startScroll();
        if (!b2.isScrolling())
            b2.startScroll();
        super.onRestart();
    }


    @Override
    protected void onResume() {
        if (!bl.isScrolling())
            bl.startScroll();
        if (!b2.isScrolling())
            b2.startScroll();
        super.onResume();
    }


    @Override
    protected void onStop() {
        bl.stopScroll();
        b2.stopScroll();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        bl.stopScroll();
        b2.stopScroll();
        super.onDestroy();
    }

    private void async(String string) {
        OkHttpUtil.getDefault(this)
                .doPostAsync(
                        HttpInfo.Builder().setUrl(" https://app.jsxzhrss.gov.cn/xzrs/appSer001/searchinfo.ke")
                                .addParam("postData", string)
                                .build(),
                        new Callback() {
                            @Override
                            public void onFailure(HttpInfo info) throws IOException {
                                String result = info.getRetDetail();
                                System.out.println("异步请求失败：" + result);
                            }

                            @Override
                            public void onSuccess(HttpInfo info) throws IOException {
                                String result = info.getRetDetail();
                                try {
                                    JSONObject object = MimaUtil.jiemi(result);
                                    msgflag = object.has("msgflag") ? object.get("msgflag").toString() : "";
                                    msg = object.has("msg") ? object.get("msg").toString() : "";
                                    flag = Integer.parseInt(msgflag);
                                    System.out.println(msg);
                                    Log.d("msgflag", msgflag);
                                    System.out.println("flag=" + flag);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                System.out.println("异步请求成功：" + result);
                                if (flag == -1) {
                                    Toast.makeText(MainActivity.this, "account or password is wrong", Toast.LENGTH_SHORT).show();
                                } else {
                                    Intent intent = new Intent(MainActivity.this, ChaXunActivity.class);

                                    intent.putExtra("info", msg);
                                    startActivity(intent);
                                    finish();

                                }
                            }
                        });
    }
    private void initkeys(String obj) {
        JSONArray dataArr = null;
        try {
            dataArr = new JSONArray(obj);
            for (int i = 0; i < dataArr.length(); i++) {
                JSONObject object = dataArr.getJSONObject(i);
                Iterator<String> it = object.keys();
                int j = 0;
                while (it.hasNext()) {
                    Query query1 = new Query();

                    String key = it.next().toString();
                    String value = object.getString(key);
                    System.out.println("key: " + key + " ** value: " + value);

                    j++;
                }

            }
            /*for (int i = 0; i < xinxi.size(); i++) {

            }*/
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
